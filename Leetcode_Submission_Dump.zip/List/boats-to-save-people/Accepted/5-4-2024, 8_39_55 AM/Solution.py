// https://leetcode.com/problems/boats-to-save-people

class Solution(object):
    def numRescueBoats(self, people, limit):
        """
        :type people: List[int]
        :type limit: int
        :rtype: int
        """
        i=0
        j=len(people)-1
        boats=0
        people.sort()
        while i<=j:
            if people[i]+people[j]<=limit:  
                i+=1
            boats+=1
            j-=1
        return boats

