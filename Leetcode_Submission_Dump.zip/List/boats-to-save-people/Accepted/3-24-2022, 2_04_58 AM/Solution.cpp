// https://leetcode.com/problems/boats-to-save-people

class Solution {
public:
    int numRescueBoats(vector<int>& p, int l) {
        
        sort(p.begin(),p.end());
        int i=0,j=p.size()-1,b=0;
        while(i<=j)
        { 
            // 1,5,4,2
            if(p[i]+p[j]<=l)
                i++;
            j--;b++;
        }
        return b;
    }
};