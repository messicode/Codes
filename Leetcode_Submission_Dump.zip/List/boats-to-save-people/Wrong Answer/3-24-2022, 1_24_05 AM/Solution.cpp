// https://leetcode.com/problems/boats-to-save-people

class Solution {
public:
    int numRescueBoats(vector<int>& p, int l) {
        
        sort(p.begin(),p.end());
        int b=0,cw=0;
        for(int i=0;i<p.size();i++)
        {
            if((cw+p[i])>l)
            {
                b++;cw=p[i];
            }
            else cw+=p[i];
        }
        
        return b+1;
    }
};