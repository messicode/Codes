// https://leetcode.com/problems/boats-to-save-people

class Solution {
public:
    int numRescueBoats(vector<int>& p, int l) {
        
        sort(p.begin(),p.end());
        vector<int> v(p.size(),0);
        int b=0;
        for(int i=0;i<p.size();i++)
        {
            if(v[i])continue;
            v[i]=1;
            int pos=-1;
            for(int j=i+1;j<p.size();j++)
                if(v[j]!=1&&p[i]+p[j]<=l)pos=j;

            if(pos!=-1)v[pos]=1;
            b++;
        }
       
        
        return b;
    }
};