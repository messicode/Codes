// https://leetcode.com/problems/binary-search

class Solution {
public:
    int search(vector<int>& ar, int t) {
         int l=0,h=ar.size()-1;

         while(l<h)
         {
             int mid=l+((h-l)>>1);// 1 2 3 4 5
             if(ar[mid]<t) l=mid+1;
             else if(ar[mid]>t) h=mid-1;
             else return mid;
         }
         return -1;
    }
};