// https://leetcode.com/problems/binary-search

class Solution {
public:
    int search(vector<int>& a, int target) {
        
        int l=0,r=a.size()-1,m,ans=-1;
        
        while(l<=r)
        {
            m=l+((r-l)>>1);
            if(a[m]==target)return m;
            else if(a[m]>target)r=m-1;
            else l=m+1;
        }
        return -1;
        
    }
};