// https://leetcode.com/problems/check-if-a-string-contains-all-binary-codes-of-size-k

class Solution {
public:
    bool hasAllCodes(string s, int k) {
        unordered_set<int> st;
        
        int cur=0,zr=(1<<(k-1))-1;
        
        for(int i=0;i<k;i++)
        {
            cur<<=1;
            cur|=(s[i]-'0');
        }
        st.insert(cur);
        for(int i=k;i<s.size();i++)
        {
            cur&=zr;cur<<=1;
            cur|=(s[i]-'0');
            st.insert(cur);
        }
        return st.size()==(1<<k);
    }
};