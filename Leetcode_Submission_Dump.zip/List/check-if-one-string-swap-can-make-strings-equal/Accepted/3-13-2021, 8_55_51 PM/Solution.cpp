// https://leetcode.com/problems/check-if-one-string-swap-can-make-strings-equal

class Solution {
public:
    bool areAlmostEqual(string s1, string s2) {
        int f=0;
        if(s1.compare(s2)==0) return true;
        for(int i=0;i<s2.length();i++)
        {
           for(int j=s2.length()-1;j>i;j--)
           {
               swap(s2.at(i),s2.at(j));
               if(s1.compare(s2)==0) return true;
               swap(s2.at(i),s2.at(j));
           }
        }
        return false;
                 
    }
};