// https://leetcode.com/problems/concatenate-non-zero-digits-and-multiply-by-sum-ii


class Solution {
    using ll=long long;
public:
    vector<int> sumAndMultiply(string s, vector<vector<int>>& queries) {
        ll MOD=1000000007;
        
        int n=s.size();
        vector<ll> val(n+1,0),tot(n+1,0),pow10(n+1,1),dcnt(n+1,0);
        for(int i=1;i<=n;i++)
            pow10[i]=(pow10[i-1]*10)%MOD; 
        

        for(int i=0;i<n;i++)
        {
            int d=s[i]-'0';
            val[i+1]=(val[i]*(d==0?1:10)+d) % MOD;
            tot[i+1]=tot[i]+d;
            dcnt[i+1]=dcnt[i]+(d!=0);
            // cout<<i<<" "<<val[i+1]<<" "<<tot[i+1]<<" "<<dcnt[i+1]<<"\n";
        }
        vector<int> ans;
        for(auto &q:queries)
        {
            ll l=q[0],r=q[1]+1,pw=pow10[dcnt[r]-dcnt[l]]%MOD;
            long long a=((( val[r]- ( val[l]*pw ) ) % MOD)+MOD)% MOD;
            // if(a<0) a+=MOD;
            a= (a*(tot[r]-tot[l]))%MOD;
            ans.push_back(a);
        }
        return ans;
    }
};