// https://leetcode.com/problems/check-if-strings-can-be-made-equal-with-operations-i

class Solution {
public:
    bool canBeEqual(string s1, string s2) {
        
        if(s1==s2)return true;
        swap(s1[0],s1[2]);
        if(s1==s2)return true;
        swap(s2[1],s2[3]);
        if(s1==s2)return true;
        swap(s2[0],s2[2]);
        if(s1==s2)return true;
        return false;
    }
};