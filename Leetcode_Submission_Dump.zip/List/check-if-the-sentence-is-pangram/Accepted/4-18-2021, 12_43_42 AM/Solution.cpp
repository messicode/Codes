// https://leetcode.com/problems/check-if-the-sentence-is-pangram

class Solution {
public:
    bool checkIfPangram(string s) {
       set<char> st;
       for(auto i:s) 
       {
           st.insert(i);
       }
        
        if(st.size()==26) return true;return false;
    }
};