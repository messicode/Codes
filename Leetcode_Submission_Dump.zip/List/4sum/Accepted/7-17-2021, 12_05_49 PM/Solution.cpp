// https://leetcode.com/problems/4sum

class Solution {
public:
    vector<vector<int>> fourSum(vector<int>& a, int t) {
        
        vector<vector<int>> ans;
        int n=a.size();
        if(n<4)return ans;
        sort(a.begin(),a.end());
        for(int i=0;i<n-3;)
        {
            for(int j=i+1;j<n-2;)
            {
                int l=j+1,r=n-1;
                while(l<r)
                { 
                    long long s=a[i]+a[j]+a[l]+a[r];
                    if(s>t) while(l<r&&a[r--]==a[r]);
                    else if(s<t)while(l<r&&a[l++]==a[l]);
                    else 
                    {
                        ans.push_back({a[i],a[j],a[l],a[r]});
                        while(l<r&&a[l++]==a[l]);
                        while(l<r&&a[r--]==a[r]);
                    }
                }
                while(j<n-2&&a[j++]==a[j]);
            }
            while(i<n-3&&a[i++]==a[i]);    
        }
        
        return ans;
    }
};