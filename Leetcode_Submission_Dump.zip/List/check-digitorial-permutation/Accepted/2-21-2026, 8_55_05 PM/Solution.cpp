// https://leetcode.com/problems/check-digitorial-permutation

class Solution {
public:
    bool isDigitorialPermutation(int n) {
        vector<int> cnt(10,0);
        int num=n, fsum=0;
        while(num)
            {
                int f=num%10, prod=1;
                cnt[f]++;
                num/=10;
                for(int i=2;i<=f;i++)
                    prod=prod*i;
                fsum+=prod;
            }
        while(fsum)
            {
                cnt[fsum%10]--;
                fsum/=10;
            }
        for(int i=0;i<10;i++)
            if(cnt[i]!=0) return false;
        return true;
    }
};