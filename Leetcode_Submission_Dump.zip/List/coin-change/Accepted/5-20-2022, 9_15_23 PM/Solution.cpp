// https://leetcode.com/problems/coin-change

class Solution {
public:
    int coinChange(vector<int>& c, int a) {
        vector<int> dp(a+1,1e5);
        dp[0]=0;
        for(int i=0;i<a;i++)
        {
            if(dp[i]==1e5)continue;
            for(int j=0;j<c.size();j++)
                if(i<=a-c[j])dp[i+c[j]]=min(1+dp[i],dp[i+c[j]]);
        }
            return dp[a]==1e5?-1:dp[a];
    }
};