// https://leetcode.com/problems/coin-change

class Solution {
public:
    int coinChange(vector<int>& co, int a) {
        vector<int> dp(a+1,1e5);
        dp[0]=0;
        
        for(int i=0;i<=a;i++)
        {
            if(dp[i]==INT_MAX)continue;
            for(auto &c:co)
            {
                if(i<=a-c)dp[i+c]=min(dp[i+c],dp[i]+1);
            }
        }
        return dp[a]==1e5?-1:dp[a];
    }
};