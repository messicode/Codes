// https://leetcode.com/problems/coin-change

class Solution {
public:
    int coinChange(vector<int>& coins, int amt) {
        vector<int> dp(amt+1,0);

        for(int a=1;a<=amt;a++)
        {
            int ans=INT_MAX;
            for(int coin:coins)
            {
                if(a>=coin)
                {   
                    ans=min(ans,dp[a-coin]);
                }
            }
            dp[a]=(ans==INT_MAX?ans:ans+1);
        }
        return dp[amt]==INT_MAX?-1:dp[amt];
    }
};