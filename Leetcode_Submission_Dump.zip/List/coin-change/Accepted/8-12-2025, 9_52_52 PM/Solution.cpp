// https://leetcode.com/problems/coin-change

class Solution {
    int h(vector<int>& cns, int amt, int i,vector<vector<int>>& dp)
    {
        if(amt==0) return 0;
        if(amt<0 || i>=cns.size()) return 1e5;
        if(dp[amt][i]!=-1) return dp[amt][i];
        return dp[amt][i]=min(h(cns,amt,i+1,dp),1+h(cns,amt-cns[i],i,dp));
    }
public:
    int coinChange(vector<int>& cns, int amt) {
        sort(cns.begin(),cns.end());
        int n=cns.size();
        vector<vector<int>> dp(amt+1,vector<int>(n+1,-1));
        int ans=h(cns,amt,0,dp);
        if(ans>=1e5) return -1;
        return ans;
    }
};