// https://leetcode.com/problems/coin-change

class Solution {
public:
    int coinChange(vector<int>& coins, int amt) {
        vector<int> dp(amt+1,1e5);
        dp[0]=0;
        for(int a=1;a<=amt;a++)
        {
            for(int coin:coins)
            {
                if(a>=coin)
                {   
                    dp[a]=min(dp[a],dp[a-coin]);
                }
            }
            dp[a]+=1;
        }
        return dp[amt]>=1e5?-1:dp[amt];
    }
};