// https://leetcode.com/problems/coin-change

class Solution {

    int h(vector<int>& cns, int amt,int i,vector<int>& dp)
    {
        if(amt==0) return 0;
        if(amt<0 || i>=cns.size()) return 1e6;
        if(dp[amt]!=-1) return dp[amt];
        int a=amt,x=0,ans=1e6;
        while(a>=0)
        {   
            int res=h(cns,a,i+1,dp);
            if(res!=-1) ans=min(ans,res+x);
            a-=cns[i];x++;
        }
        return dp[amt]=(ans>=1e6?-1:ans);
    }
public:
    int coinChange(vector<int>& cns, int amt) {
        vector<int> dp(amt+1,-1);
        return h(cns,amt,0,dp);
    }
};