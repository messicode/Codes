// https://leetcode.com/problems/coin-change

class Solution {
public:

    vector<int> dp=vector<int>(1e5,-1);
    int coinChange(vector<int>& c, int a) {
        if(a==0)return 0;
        if(a<0)return -1;
        if(dp[a]!=-1)return dp[a];
        int mn=1e5;
        for(int i=0;i<c.size();i++)
        {int x=coinChange(c,a-c[i]);x=(x==-1)?1e5:x;mn=min(x,mn);}
        return dp[a]=((mn==1e5)?-1:(mn+1));
    }
};