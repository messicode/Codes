// https://leetcode.com/problems/coin-change

class Solution {

    int h(vector<int>& cns, int amt,int i,vector<vector<int>>& dp)
    {
        if(amt==0) return 0;
        if(amt<0 || i>=cns.size()) return 1e6;
        if(dp[amt][i]!=-1) return dp[amt][i];
        int a=amt,x=0,ans=1e6;
        while(a>=0)
        {   
            int res=h(cns,a,i+1,dp);
            if(res!=-1) ans=min(ans,res+x);
            a-=cns[i];x++;
        }
        return dp[amt][i]=(ans>=1e6?-1:ans);
    }
public:
    int coinChange(vector<int>& cns, int amt) {
        vector<vector<int>> dp(amt+1,vector<int>(cns.size()+1,-1));
        return h(cns,amt,0,dp);
    }
};