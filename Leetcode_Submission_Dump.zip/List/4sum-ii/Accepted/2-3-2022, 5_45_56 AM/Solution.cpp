// https://leetcode.com/problems/4sum-ii

class Solution {
public:
    int fourSumCount(vector<int>& a1, vector<int>& a2, vector<int>& a3, vector<int>& a4) {
        int n=a1.size(),c=0;
        map<int,int> m;
        
        for(auto i:a3) for(auto j:a4) m[i+j]++;
        
        for(auto i:a1)
            for(auto j:a2)
            {
                if(m.find(-(i+j))!=m.end())c+=m[-(i+j)];
            }
        
        return c;
    }
};