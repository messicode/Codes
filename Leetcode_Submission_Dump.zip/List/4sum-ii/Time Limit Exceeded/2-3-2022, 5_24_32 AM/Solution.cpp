// https://leetcode.com/problems/4sum-ii

class Solution {
public:
    int fourSumCount(vector<int>& a1, vector<int>& a2, vector<int>& a3, vector<int>& a4) {
        int n=a1.size(),c=0;
        sort(a3.begin(),a3.end());
        sort(a4.begin(),a4.end());
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
            {
                int s=-1*(a1[i]+a2[j]),x=0,y=n-1;
                while(x<n&&y>=0)
                {
                    int z=a3[x]+a4[y];
                    
                    if(s==z)
                    {
                        int x1=0,y1=0,m=a3[x];
                        while(x<n&&m==a3[x])x++,x1++;
                        m=a4[y];
                        while(y>=0&&a4[y]==m)y--,y1++;
                        c+=x1*y1;    
                    }
                    else if(z<s)x++;else y--;
                    
                }
                
            }
        
        return c;
    }
};