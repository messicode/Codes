// https://leetcode.com/problems/concatenate-non-zero-digits-and-multiply-by-sum-i

class Solution {
public:
    long long sumAndMultiply(int n) {
        long long ans=0,sum=0,mt=1;
        while(n)
            {
                long long d=n%10;
                n/=10;
                if(d)
                {
                    sum+=d;
                    ans+=(d*mt);
                    mt*=10;
                }
                
            }
        return sum*ans;
    }
};