// https://leetcode.com/problems/angles-of-a-triangle

class Solution {
public:
    vector<double> internalAngles(vector<int>& sides) {
        vector<double> ans(3,0);
        double a=sides[0],b=sides[1],c=sides[2];

        if( ((a+b)<=c) || ((a+c)<=b) || ((b+c)<=a))return {};
        ans[0]=180*( acos( ((a*a)+ (b*b) - (c*c) )/(2.0*a*b)) )/M_PI;
        ans[1]=180*(acos( ((c*c)+ (b*b) - (a*a) )/(2.0*c*b)))/(M_PI);
        ans[2]=180*(acos( ((a*a)+ (c*c) - (b*b) )/(2.0*a*c)))/(M_PI);
        sort(ans.begin(),ans.end());
        return ans;
    }
};