// https://leetcode.com/problems/balanced-k-factor-decomposition

class Solution {
    using ll=long long;
    // mp min dist-> its map of k divs
    // vector<int> ans;
    // int diff=INT_MAX;
    void rec(int k, int n,vector<int> &divs,vector<int> &curr,vector<int> &ans,int &diff)
    {
        // cout<<n<<" "<<k<<"\n";
        
        if(k==1)//check minD
        {
            curr.push_back(n);
            int mx=*max_element(curr.begin(),curr.end());
            int mn=*min_element(curr.begin(),curr.end());
            if(mx-mn < diff)
            {
                diff=mx-mn;
                ans=curr;
            }
            curr.pop_back();
            return;
        }
        
        for(auto &d:divs)
        {
            if(n%d==0)
            {
                curr.push_back(d);
                rec(k-1,n/d,divs,curr,ans,diff);
                curr.pop_back();
            }
        }

        return;
    }
    
public:
    vector<int> minDifference(int n, int k) {
        vector<int> divs,curr,ans;
        int sq=sqrt(n),diff=INT_MAX;sq*=sq;
        // if(k==2 && n==sq) return sq;
        for(int i=1;i<=sq;i++)if(n%i==0)divs.push_back(i);
        rec(k,n,divs,curr,ans,diff);
        return ans;
        
        
    }
};