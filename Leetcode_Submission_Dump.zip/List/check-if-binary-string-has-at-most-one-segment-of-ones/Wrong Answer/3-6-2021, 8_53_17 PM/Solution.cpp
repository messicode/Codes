// https://leetcode.com/problems/check-if-binary-string-has-at-most-one-segment-of-ones

class Solution {
public:
    bool checkOnesSegment(string s) {
        int n=s.length();
        if(n<2) return true;
        for(int i=0;i<n;i++)
            if(s[i]=='1' &&  s[i+1]=='1') return true;
        return false;
    }
};