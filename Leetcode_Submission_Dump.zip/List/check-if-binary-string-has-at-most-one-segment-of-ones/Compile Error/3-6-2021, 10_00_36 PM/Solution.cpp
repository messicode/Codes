// https://leetcode.com/problems/check-if-binary-string-has-at-most-one-segment-of-ones

class Solution {
public:
    bool checkOnesSegment(string s) {
        int n=s.length();
        if(n<2) return true;
        int c=0;
        for(int i=0;i<n-1;i++)
        {
            if(s[i]=='1'){
                c++;        
            }
            if(s[i]=='1' && s[i+1]=='1')
            {
                return true;
            }
        }
        if(c<=2) return false;
    }
};