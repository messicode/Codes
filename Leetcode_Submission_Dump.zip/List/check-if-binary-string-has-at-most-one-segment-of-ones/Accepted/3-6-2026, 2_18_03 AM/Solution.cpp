// https://leetcode.com/problems/check-if-binary-string-has-at-most-one-segment-of-ones

class Solution {
public:
    bool checkOnesSegment(string s) {
        int n=s.size(),i=0;
        while(i<n&&s[i]=='1')i++;
        while(i<n&&s[i]=='0')i++;
        return i==n;
    }
};