// https://leetcode.com/problems/check-if-binary-string-has-at-most-one-segment-of-ones

class Solution {
public:
    bool checkOnesSegment(string s) {
        int n=s.length();
        if(n<2) return true;
        int c=0,u=0;
        for(int i=0;i<n;i++) if(s[i]=='0' && s[i+1]=='1') return false;
        return true;
    }
};