// https://leetcode.com/problems/01-matrix

class Solution {
public:
    vector<vector<int>> updateMatrix(vector<vector<int>>& g) {
        
        int n=g.size(),m=g[0].size();
        vector<vector<int>> ans(n,vector<int>(m,0));
        
        queue<pair<int,int>> q;
        for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
            {
                if(!g[i][j])q.push({i,j});
            }
        int of[]={0,-1,0,1,0};
        int d=0;
        while(!q.empty())
        {
            d++;
            int sz=q.size();
            
            while(sz--)
            {
                int i,j,r,c;tie(i,j)=q.front();q.pop();
                for(int l=0;l<4;l++)
                {
                    r=i+of[l],c=j+of[l+1];
                    if(r>=0&&c>=0&&r<n&&c<m&&ans[r][c]==0&&g[r][c]!=0)
                    { ans[r][c]=d;q.push({r,c}); }
                }
            }
        }
        return ans;
    }
};