// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-ii

class Solution {
public:
    int maxProfit(vector<int>& p) {
        int b=p[0],s=p[0],t=0;// 1 5 3 8
        for(int i=1;i<p.size();i++)
        {
            if(s>=p[i])
            {
                t+=s-b;b=p[i];s=p[i];
            }
            else s=p[i];
        }
        t+=s-b;
        return t;
    }
};