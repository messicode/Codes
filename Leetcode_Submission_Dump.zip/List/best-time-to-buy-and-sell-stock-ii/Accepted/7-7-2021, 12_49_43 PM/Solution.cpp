// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-ii

class Solution {
public:
    int maxProfit(vector<int>& a) {
        int n=a.size(),s=0,mn=a[0],mx=a[0];
        //PV APPROACH
        for(int i=1;i<n;i++)
        {
            if(a[i]<a[i-1])
            {
                s+=(mx-mn);
                mn=mx=a[i];
            }
            else mx=a[i];
        }
        s+=(mx-mn);
        return s;
    }
};