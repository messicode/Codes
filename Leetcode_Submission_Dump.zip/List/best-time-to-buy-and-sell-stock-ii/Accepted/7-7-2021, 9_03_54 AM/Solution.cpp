// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-ii

class Solution {
public:
    int maxProfit(vector<int>& a) {
        int n=a.size(),s=0;
        for(int i=1;i<n;i++)
        {
            if(a[i]>a[i-1]) s+=a[i]-a[i-1];
        }
        return s;
    }
};