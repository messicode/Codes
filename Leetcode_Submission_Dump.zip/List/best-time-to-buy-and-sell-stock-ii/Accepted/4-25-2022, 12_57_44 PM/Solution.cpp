// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-ii

class Solution {
public:
    int maxProfit(vector<int>& p) {
        // 7 1 5 4 600 4
        int a=p[0],mx=0;
        
        for(int i=1;i<p.size();i++)
        {
            if(p[i]<p[i-1])
            {
                mx+=p[i-1]-a;a=p[i];
            }
            
        }
        mx+=p[p.size()-1]-a;
        return mx;
    }
};