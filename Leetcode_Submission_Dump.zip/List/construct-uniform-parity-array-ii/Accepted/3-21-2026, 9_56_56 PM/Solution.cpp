// https://leetcode.com/problems/construct-uniform-parity-array-ii

class Solution {
public:
    bool uniformArray(vector<int>& nums1) {
        int sm=INT_MAX,o=0;
        for(auto &n:nums1)
            {
                if(n&1)o++;
                sm=min(sm,n);
            }
        // cout<<sm<<" "<<o<<" ";
        if(sm%2 == 0 && o>0)return false;
        return true;
    }
};