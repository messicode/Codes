// https://leetcode.com/problems/combination-sum

class Solution {
public:
    vector<vector<int>> combinationSum(vector<int>& can, int t) {
        
        vector<vector<vector<int>>> v;
        vector<vector<int>> ans;
        
        v.push_back({{}});
        
        for(int i=1;i<=t;i++)
        {
            vector<vector<int>> a;    
            for(int j=0;j<can.size();j++)
            {
                if(can[j]>i)continue;
                vector<vector<int>> x=v[i-can[j]];
                if(x.size()==0)continue;
                for(int k=0;k<x.size();k++)
                {x[k].push_back(can[j]);a.push_back(x[k]);}
                
            }
            v.push_back(a);
        }
        // cout<<v.size()<<" "<<v[t].size()<<"\n";
        set<vector<int>> u;
        for(auto i:v[t])
        {
            sort(i.begin(),i.end());
            u.insert(i);
        }
        
        for(auto i:u)
        {
            // for(int j=0;j<i.size();j++)
            // cout<<i[j]<<" ";
            // cout<<endl;
            ans.push_back(i);
        }
        return ans;
        
    }
};