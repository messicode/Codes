// https://leetcode.com/problems/combination-sum

class Solution {
public:
    
    void func(vector<int> can,int t,vector<vector<int>> &ans,vector<int> cur,int i)
    {
        if(t<0)return;
        if(t==0)
        {
            ans.push_back(cur);
            return;
        }
        for(int j=i;j<can.size();j++)
        {
            if(t<can[j])continue;
            cur.push_back(can[j]);
            func(can,t-can[j],ans,cur,j);
            cur.pop_back();
        }
    }
    
    vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
        vector<vector<int>> ans;
        vector<int> cur;
        func(candidates,target,ans,cur,0);
        return ans;
    }
};