// https://leetcode.com/problems/combination-sum

class Solution {
public:
    vector<vector<int>> combinationSum(vector<int>& c, int t) {
        int n=c.size();
        vector<vector<vector<vector<int>>>> dp(t+1,vector<vector<vector<int>>>(n+1));
        
        for(int i=0;i<=n;i++)dp[0][i].push_back({});
        
        for(int i=1;i<=t;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(dp[i][j-1].size()!=0)
                    for(auto v:dp[i][j-1])
                    dp[i][j].push_back(v);
                if(i-c[j-1]<0||dp[i-c[j-1]][j].size()==0)continue;
                for(auto v:dp[i-c[j-1]][j])
                {
                    v.push_back(c[j-1]);
                    dp[i][j].push_back(v);
                }
            }
            
        }
        
        return dp[t][n];
        
    }
};