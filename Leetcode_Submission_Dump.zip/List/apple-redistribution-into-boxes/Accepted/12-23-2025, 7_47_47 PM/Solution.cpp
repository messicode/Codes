// https://leetcode.com/problems/apple-redistribution-into-boxes

class Solution {
public:
    int minimumBoxes(vector<int>& ap, vector<int>& cap) {
        sort(begin(cap),end(cap),greater<int>());
        int tot=accumulate(begin(ap),end(ap),0);
        int c=0;
        for(auto &i:cap)
        {
            tot-=i;c++;
            if(tot<=0)return c;
        }
        return c;
    }
};