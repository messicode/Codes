// https://leetcode.com/problems/balance-a-binary-search-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {

    TreeNode* bst(vector<int> &in,int s,int e)
    {
        if(s>e)return nullptr;
        int m=((e+s)/2);
        TreeNode* l=bst(in,s,m-1);
        TreeNode* r=bst(in,m+1,e);
        // cout<<s<<" "<<e<<"\n";
        return new TreeNode(in[m],l,r);
    }

public:
    TreeNode* balanceBST(TreeNode* root) {
        stack<TreeNode*> st;
        vector<int> in;
        TreeNode* curr=root;//curr to be processed
        while(curr!=nullptr||!st.empty())
        {
            while(curr!=nullptr)
            {
                st.push(curr);
                curr=curr->left;
            }
            curr=st.top();
            st.pop();
            in.push_back(curr->val);
            curr=curr->right;
        }   

        return bst(in,0,in.size()-1);
    }
};