// https://leetcode.com/problems/coin-change-ii

class Solution {
public:
    int change(int a, vector<int>& c) {
        
        int n=c.size();
        vector<vector<int>> dp(n+1,vector<int>(a+1,0));
        for(int i=0;i<=n;i++)dp[i][0]=1;
        
        for(int i=1;i<=n;i++)
        {
            for(int s=1;s<=a;s++)
            {
                dp[i][s]=dp[i-1][s]+((s>=c[i-1])?dp[i][s-c[i-1]]:0);
            }
        }
        return dp[n][a];
    }
};