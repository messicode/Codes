// https://leetcode.com/problems/cinema-seat-allocation

class Solution {
public:
    int maxNumberOfFamilies(int n, vector<vector<int>>& rs) {
        //8bit seat info
        sort(rs.begin(),rs.end());
        int m=rs.size(),ans=0;
        
        for(int i=0;i<m;i++)
        {

            int j=i,prev=1;
            while(j<m && rs[j][0]==rs[i][0])
            {
                int diff=rs[j][1]-prev;

                if(diff>4)
                {
                    if(prev<=1 && rs[j][1]>=10)ans+=2;
                    else if(prev<=1 && rs[j][1]>=6) ans++;
                    else if(prev<=5 && rs[j][1]>=10) ans++;
                    else if(prev<=3 && rs[j][1]>=8) ans++;
                    // cout<<j<<" "<<ans<<endl;
                }
                prev=rs[j][1];
                j++;
            }
            // cout<<i<<" "<<ans<<"\n";
            ans+=((10-prev-1)/4);
            // cout<<i<<" "<<ans<<"\n";
            if(j<m && (rs[j][0]-rs[i][0])>1)
            ans+=(2*(rs[j][0]-rs[i][0]-1));
            // cout<<i<<" "<<ans<<"\n";
            i=j-1;
            
        }
        ans+=(rs[0][0]-1+n-rs[m-1][0])*2;
        return ans;
    }
};