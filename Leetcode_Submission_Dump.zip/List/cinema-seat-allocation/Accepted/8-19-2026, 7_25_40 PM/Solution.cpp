// https://leetcode.com/problems/cinema-seat-allocation

class Solution {
public:
    int maxNumberOfFamilies(int n, vector<vector<int>>& rSt) {
        int ans=0;
        vector<int> rw(11,1);
        sort(rSt.begin(),rSt.end());
        int lr=1;
        for(int i=0;i<rSt.size();i++)
        {
            // cout<<lr<<" ";
            while(i<rSt.size()&&lr==rSt[i][0])
            {
                rw[rSt[i][1]]=0;i++;
            }
            i--;lr++;
            int a=0;
            if(rw[2]&&rw[3]&&rw[4]&&rw[5])a++;
            if(rw[6]&&rw[7]&&rw[8]&&rw[9])a++;
            if(!a && (rw[4]&&rw[5]&&rw[6]&&rw[7]))a++;
            // cout<<a<<"\n";
            ans+=a;
            fill(rw.begin(),rw.end(),1);
        }
        ans+=max(n-lr+1,0)*2;
        return ans;
    }
};