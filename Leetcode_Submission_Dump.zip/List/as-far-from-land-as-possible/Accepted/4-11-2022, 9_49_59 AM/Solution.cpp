// https://leetcode.com/problems/as-far-from-land-as-possible

class Solution {
public:
    int maxDistance(vector<vector<int>>& g) {
        
        int n=g.size();
        queue<pair<int,int>> q;
        for(int i=0;i<n;i++)
            for(int j=0;j<n;j++)
                if(g[i][j]==1)q.push({i,j});
        
        int ans=0;
        int of[]={0,-1,0,1,0};
        while(!q.empty())
        {
            ans++;
            int sz=q.size();
            while(sz--)
            {
                int i=q.front().first,j=q.front().second;
                q.pop();
                for(int l=0;l<4;l++)
                {
                    int r=i+of[l],c=j+of[l+1];
                    if(r>=0&&c>=0&&r<n&&c<n&&g[r][c]==0)
                    {g[r][c]=ans+1;q.push({r,c});}   
                }
            }
        }
        return ans<=1?-1:ans-1;
    }
};
