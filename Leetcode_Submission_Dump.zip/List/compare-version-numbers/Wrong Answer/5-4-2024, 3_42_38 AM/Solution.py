// https://leetcode.com/problems/compare-version-numbers

class Solution(object):
    def compareVersion(self, v1, v2):
        """
        :type version1: str
        :type version2: str
        :rtype: int
        """
        i=0
        j=0
        while i<len(v1) and j<len(v2):
            n1=0
            n2=0
            while i<len(v1) and v1[i]!='.':
                n1+= 10*n1 + int(v1[i]) 
                i+=1
            while j<len(v2) and v2[j]!='.':
                n2+= 10*n2 + int(v2[j])
                j+=1
            if n1<n2: return -1
            elif n1>n2: return 1
            i+=1
            j+=1
        return 0