// https://leetcode.com/problems/compare-version-numbers

class Solution {
public:
    
    
    int compareVersion(string v1, string v2) {
        int i=0,j=0;
        
        while(i<v1.size()||j<v2.size())
        {
            int p1=0,p2=0;
            while(i<v1.size()&&v1[i]!='.')p1=p1*10+(v1[i++]-'0');
            i++;
            while(j<v2.size()&&v2[j]!='.')p2=p2*10+(v2[j++]-'0');
            j++;
            if(p1<p2)return -1;
            if(p1>p2)return 1;
        }
        return 0;
        
    }
};