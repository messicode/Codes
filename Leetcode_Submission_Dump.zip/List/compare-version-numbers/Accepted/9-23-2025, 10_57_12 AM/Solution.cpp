// https://leetcode.com/problems/compare-version-numbers

class Solution {
public:
    int compareVersion(string v1, string v2) {
        
        int s1=v1.size(),s2=v2.size(),n=min(s1,s2),i=0,j=0;
        while(i<s1 || j<s2)
        {
            int val1=0,val2=0;
            while(i<s1 && v1[i]!='.')
            {
                val1=val1*10+(v1[i]-'0');
                i++;
            }
            while(j<s2 && v2[j]!='.')
            {
                val2=val2*10+(v2[j]-'0');
                j++;
            }
            if(val1>val2) return 1;
            else if(val1<val2) return -1;
            i++,j++;
        }

        return 0;
    }
};