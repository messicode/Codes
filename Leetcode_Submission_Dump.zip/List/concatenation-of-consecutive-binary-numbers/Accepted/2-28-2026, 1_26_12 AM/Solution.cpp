// https://leetcode.com/problems/concatenation-of-consecutive-binary-numbers

class Solution {
public:
    int concatenatedBinary(int n) {
        int MOD=1e9+7;
        long ans=0;
        for(int i=1;i<=n;i++)
        {
            int j=floor(log2(i));
            while(j>=0)
            {
                ans=( (ans<<1) | ((i>>j) & 1) )%MOD;
                // cout<<ans<<" ";
                j--;
            }
        }
        return ans;
    }
};