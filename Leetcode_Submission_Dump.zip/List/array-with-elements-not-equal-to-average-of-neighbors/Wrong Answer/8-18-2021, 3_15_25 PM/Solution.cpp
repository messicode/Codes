// https://leetcode.com/problems/array-with-elements-not-equal-to-average-of-neighbors

class Solution {
public:
    vector<int> rearrangeArray(vector<int>& a) {
        int n=a.size();
        sort(a.begin(),a.end());
        for(int i=1;i<n-1;i++)
        {
            if((a[i]-a[i-1])==(a[i+1]-a[i]))swap(a[i],a[i-1]);
        }
        return a;
    }
};