// https://leetcode.com/problems/array-with-elements-not-equal-to-average-of-neighbors

class Solution {
public:
    vector<int> rearrangeArray(vector<int>& a) {
        int n=a.size(),i=0;
        sort(a.begin(),a.end());
        for(int i=1;i<n;i+=2)
        {
            swap(a[i-1],a[i]);
        }
        return a;
    }
};