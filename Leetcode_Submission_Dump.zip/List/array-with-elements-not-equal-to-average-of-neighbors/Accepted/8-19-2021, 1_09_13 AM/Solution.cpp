// https://leetcode.com/problems/array-with-elements-not-equal-to-average-of-neighbors

class Solution {
public:
    vector<int> rearrangeArray(vector<int>& a) {
        int n=a.size(),i=0,k=0;int j=n-1;
        vector<int> b(n);
        b[0]=a[0];
        sort(a.begin(),a.end());
        while(i<=j)
        {
            if(k&1)b[k++]=a[j--];
            else b[k++]=a[i++];
        }
        
        return b;
    }
};