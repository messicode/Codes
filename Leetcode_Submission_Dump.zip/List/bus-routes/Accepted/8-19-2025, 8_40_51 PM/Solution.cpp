// https://leetcode.com/problems/bus-routes

class Solution {
public:
    int numBusesToDestination(vector<vector<int>>& routes, int src, int trg) {
        
        if(src==trg) return 0;
        
        int b=routes.size();
        vector<vector<int>> stop(1e5,vector<int>());//stop->buses
        
        for(int i=0;i<routes.size();i++)
        {
            for(int j=0;j<routes[i].size();j++)
            {
                stop[routes[i][j]].push_back(i);
            }
        }

        queue<int> q;q.push(src);
        vector<bool> vis(1e5,false);//stop vis
        vector<bool> visb(b,false);//stop bus
        
        vis[src]=true;
        int ans=0;
        while(!q.empty())
        {
            int sz=q.size();
            ans++;
            while(sz--)
            {
                int st=q.front();q.pop();
                
                for(auto &bs:stop[st])
                {
                    if(!visb[bs])
                    {
                        visb[bs]=true;
                        for(int k=0;k<routes[bs].size();k++)
                        {
                            int new_stop=routes[bs][k];
                            if(trg==new_stop) return ans;//found the target stop
                            if(!vis[new_stop]) 
                            {vis[new_stop]=true;q.push(new_stop);}//explore stop 
                        }
                    }
                }

            }
        }

        return -1;

    }
};