// https://leetcode.com/problems/arithmetic-slices

class Solution {
public:
    int numberOfArithmeticSlices(vector<int>& nums) {
        
        int n=nums.size();
        if(n<3)return 0;
        int c=2,ans=0;
        for(int i=2;i<n;i++)
        {
            while(i<n&&nums[i]-nums[i-1]==nums[i-1]-nums[i-2]){c++;i++;}
            if(c>2)
            {
                ans+=(c-1)*(c-2)/2;
                c=2;
            }
        }
        return ans;
    }
};