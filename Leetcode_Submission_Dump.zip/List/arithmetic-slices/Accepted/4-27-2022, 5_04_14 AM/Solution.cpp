// https://leetcode.com/problems/arithmetic-slices

class Solution {
public:
    int numberOfArithmeticSlices(vector<int>& nums) {
        
        int ans=0,l=0;
        if(nums.size()<3)return 0;
        
        for(int i=1;i<nums.size()-1;i++)
        {
            l=0;
            while(i<nums.size()-1&&nums[i]-nums[i-1]==nums[i+1]-nums[i])l++,i++;
            ans+=(l*(l+1))>>1;
        }
        return ans;
    }
};