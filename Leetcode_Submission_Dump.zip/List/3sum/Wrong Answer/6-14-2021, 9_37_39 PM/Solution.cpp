// https://leetcode.com/problems/3sum

class Solution {
public:
    vector<vector<int>> threeSum(vector<int>& a) {
        vector<vector<int>> ans;
        sort(a.begin(),a.end());
        for(int i=0;i<a.size();)
        {int t=0-a[i],l=i+1,h=a.size()-1;
         
            while(l<h)
            {int sum=a[l]+a[h];
                if(sum==t)
                {
                    ans.push_back(vector<int> {a[i],a[l],a[h]});
                    while(a[++l]==a[l]&&l<h);
                    while(a[--h]==a[h]&&l<h);
                }
                else if (sum>t) h--;
                else l++;
            }
         while (((++i)<a.size())&&a[i] == a[i - 1]);
        }
        return ans;
    }
};