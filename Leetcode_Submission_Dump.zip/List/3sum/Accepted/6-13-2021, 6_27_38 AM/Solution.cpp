// https://leetcode.com/problems/3sum

class Solution {
public:
    vector<vector<int>> threeSum(vector<int>& a) {
        set<vector<int>> ans; 
        sort(a.begin(),a.end());
        for(int i=0;i<a.size();i++)
        {int t=0-a[i],l=i+1,h=a.size()-1;
         
            while(l<h)
            {int sum=a[l]+a[h];
                if(sum==t)
                {
                    vector<int> s(3);
                    s[0]=a[i];s[1]=a[l];s[2]=a[h];
                    ans.insert(s);
                    l++;h--;
                }
                else if (sum>t) h--;
                else l++;
            }
        }
        vector<vector<int>> v(ans.begin(),ans.end()); 
        return v;
    }
};