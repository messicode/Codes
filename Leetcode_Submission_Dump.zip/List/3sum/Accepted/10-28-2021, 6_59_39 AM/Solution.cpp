// https://leetcode.com/problems/3sum

class Solution {
public:
    vector<vector<int>> threeSum(vector<int>& a) {
        
        vector<vector<int>> t;
        if(a.size()<3)return t;
        int s=0;
        sort(a.begin(),a.end());
        for(int i=0;i<a.size()-1;i++)
        {
            int l=i+1,h=a.size()-1,v=0;
            while(l<h)
            {
                v=a[i]+a[l]+a[h];
                if(!v)
                {
                    t.push_back({a[i],a[l],a[h]});
                    while(l<h&&a[l++]==a[l]);
                    while(l<h&&a[h--]==a[h]);
                }
                else if(v<0) while(l<h&&a[l++]==a[l]);
                else while(l<h&&a[h--]==a[h]);
            }
            while(i<a.size()-1&&a[i+1]==a[i])i++;
        }
        return t;
    }
};