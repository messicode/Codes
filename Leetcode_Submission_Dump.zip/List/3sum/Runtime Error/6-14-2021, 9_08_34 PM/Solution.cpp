// https://leetcode.com/problems/3sum

class Solution {
public:
    vector<vector<int>> threeSum(vector<int>& a) {
        vector<vector<int>> ans; 
        sort(a.begin(),a.end());
        for(int i=0;i<a.size();i++)
        {int t=0-a[i],l=i+1,h=a.size()-1;
         
            while(l<h)
            {int sum=a[l]+a[h];
                if(sum==t)
                {
                    vector<int> s(3);
                    s[0]=a[i];s[1]=a[l];s[2]=a[h];
                    ans.push_back(s);
                    while(a[l]==s[1]&&l<h)l++;
                    while(a[h]==s[2]&&l<h)h--;
                }
                else if (sum>t) h--;
                else l++;
            }
         while(a[i]==a[i+1] && i+1<a.size())i++;
        }
        return ans;
    }
};