// https://leetcode.com/problems/car-pooling

class Solution {
public:
    bool carPooling(vector<vector<int>>& tr, int cap) {
        vector<int> i(1001,0),o(1001,0);
        for(auto a:tr)
        {
            i[a[1]]+=a[0];
            o[a[2]]+=a[0];
        }
        int c=0;
        for(int j=0;j<1001;j++)
        {
            c=c+i[j]-o[j];
            if(c>cap)return false;
        }
        return true;
    }
};