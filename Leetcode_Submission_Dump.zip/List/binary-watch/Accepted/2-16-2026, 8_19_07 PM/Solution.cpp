// https://leetcode.com/problems/binary-watch

class Solution {
    
public:
    vector<string> readBinaryWatch(int t) {
        vector<string> ans;
        
        for(int i=0;i<12;i++)
        {
            int mc=t-(__builtin_popcount(i));
            if(mc<0)continue;
            for(int j=0;j<60;j++)
            {
                if(__builtin_popcount(j) == mc)
                {
                    string a=to_string(i)+":"+(j<10?"0":"")+to_string(j);
                    ans.push_back(a);
                }
            }
        }

        return ans;
    }
};