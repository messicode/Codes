// https://leetcode.com/problems/check-if-array-is-sorted-and-rotated

class Solution {
public:
    bool check(vector<int>& a) {
        
        int s=a.size(),c=1;
        for(int i=0;i<(2*s);i++)
        {
            if(a[i%s]<=a[(i+1)%s]) c++;
            else c=1;
            cout<<i<<" "<<c<<endl;
            if(c==s) return true;
        }
        return false;
    }
};