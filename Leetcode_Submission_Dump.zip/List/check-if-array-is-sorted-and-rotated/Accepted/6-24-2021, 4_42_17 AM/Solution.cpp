// https://leetcode.com/problems/check-if-array-is-sorted-and-rotated

class Solution {
public:
    bool check(vector<int>& a) {
        
        int s=a.size(),c=0;
        for(int i=0;i<s;i++)
        if(a[i]>a[(i+1)%s] && ++c>1)
        return false;
        return true;
    }
};