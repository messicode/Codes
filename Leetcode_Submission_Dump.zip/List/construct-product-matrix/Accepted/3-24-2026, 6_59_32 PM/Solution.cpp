// https://leetcode.com/problems/construct-product-matrix

class Solution {
    int MOD=12345;
public:
    vector<vector<int>> constructProductMatrix(vector<vector<int>>& grid) {
        int m=grid.size(),n=grid[0].size();
        vector<vector<int>> prod(m,vector<int>(n,1));
        int pref=1;
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                prod[i][j]=pref;
                pref=(pref*(grid[i][j]%MOD))%MOD;
            }
        } 
        pref=1;
        for(int i=m-1;i>=0;i--)
        {
            for(int j=n-1;j>=0;j--)
            {
                prod[i][j]=(prod[i][j]*(pref%MOD))%MOD;
                pref=(pref*(grid[i][j]%MOD))%MOD;
            }
        }

        return prod;
    }
};