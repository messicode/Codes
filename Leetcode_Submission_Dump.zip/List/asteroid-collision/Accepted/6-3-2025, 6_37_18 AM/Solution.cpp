// https://leetcode.com/problems/asteroid-collision

class Solution {
public:
    vector<int> asteroidCollision(vector<int>& ast) {
         //10 2 -5 12 -11
         //10 12
         
         //10 2 -5 12 -13
         //-13
        
        //
        //stack->
        stack<int> st;
        int i=0;
        while(i<ast.size())
        {
            if(ast[i]>0)
                st.push(ast[i]);
            else
            {
                int x=abs(ast[i]);
                while(!st.empty()&&x>st.top() && st.top()>0)st.pop();
                if(st.empty() || st.top()<0)st.push(ast[i]);
                if(st.top()==x)st.pop();
            }
            i++;
        }
        vector<int> ans;
        while(!st.empty())
        {
            ans.push_back(st.top());st.pop();
        }
        reverse(ans.begin(),ans.end());
        return ans;
    }
};