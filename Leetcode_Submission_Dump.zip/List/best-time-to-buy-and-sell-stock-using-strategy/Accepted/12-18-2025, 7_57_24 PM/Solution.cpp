// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-using-strategy

class Solution {
    using ll=long long;
public:
    long long maxProfit(vector<int>& prc, vector<int>& strt, int k) {
        int n=prc.size();
        vector<ll> pprc(n+1,0), prof(n+1,0);

        for(int i=0;i<n;i++)
        {
            pprc[i+1]=pprc[i]+prc[i];
            prof[i+1]=prof[i]+(prc[i]*strt[i]);
        }
        int pos=0;
        ll mn=LLONG_MAX,ans=prof[n],tot=prof[n];

        //take windows from prefix
        for(int i=k;i<=n;i++)
        {
            int st=i-k;//window from st+1 to st+k
            ll wp=prof[i]-prof[st],hws=pprc[i]-pprc[i-(k/2)];
            ans=max(ans,tot-wp+hws);
        }

        return ans;
    }
};