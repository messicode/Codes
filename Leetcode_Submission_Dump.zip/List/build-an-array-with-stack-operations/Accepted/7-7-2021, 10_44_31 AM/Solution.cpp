// https://leetcode.com/problems/build-an-array-with-stack-operations

class Solution {
public:
    vector<string> buildArray(vector<int>& a, int n) {
        
        vector<string> v;
        for(int i=1,j=0;j<a.size();i++)
        {
            if(a[j]==i)
            {
                j++;
                v.push_back("Push");
            }            
            else  
            {
                v.push_back("Push");
                v.push_back("Pop");
            }
        }
        return v;
    }
};