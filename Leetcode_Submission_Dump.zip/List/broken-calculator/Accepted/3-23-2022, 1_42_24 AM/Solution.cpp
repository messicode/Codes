// https://leetcode.com/problems/broken-calculator

class Solution {
public:
    int brokenCalc(int sv, int t) {
        
        if(t<=sv)return sv-t;
        
        int ops=0;
        while(t>sv)
        {
            if(t&1)t+=1;
            else t/=2;
            ops++;
        }
        return ops+sv-t;
    }
};