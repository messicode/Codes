// https://leetcode.com/problems/add-digits

class Solution {
public:
    int addDigits(int num) {
        num=num%9;
        return (num==0)?9:num;
    }
};