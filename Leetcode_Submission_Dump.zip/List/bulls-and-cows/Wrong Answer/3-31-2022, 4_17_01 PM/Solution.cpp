// https://leetcode.com/problems/bulls-and-cows

class Solution {
public:
    string getHint(string s, string g) {
        
        vector<int> s1(10,0);
        int a=0,b=0,n=s.size();
        for(auto i:s) s1[i-'0']++;
        
        for(int i=0;i<n;i++)
            if(s[i]==g[i])
            {
                s1[g[i]-'0']--;a++;
            }
        for(int i=0;i<n;i++)
            if(s[i]!=g[i]){b+=s1[g[i]-'0'];s1[g[i]-'0']=0;}
        return (to_string(a)+"A"+to_string(b)+"B");
    }
};