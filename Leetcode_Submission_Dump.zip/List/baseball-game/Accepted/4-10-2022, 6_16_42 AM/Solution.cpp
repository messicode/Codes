// https://leetcode.com/problems/baseball-game

class Solution {
public:
    int calPoints(vector<string>& ops) {
        stack<int> st;
        int a,b;
        for(int i=0;i<ops.size();i++)
        {
            if(ops[i]=="+") {a=st.top();st.pop();b=st.top();st.push(a);st.push(b+a);}
            else if(ops[i]=="C") st.pop();    
            else if(ops[i]=="D") st.push(2*st.top());
            else st.push(stoi(ops[i]));
            
        }
        int ans=0;
        while(!st.empty())
        {
            ans+=st.top();st.pop();
        }
        return ans;
    }
};