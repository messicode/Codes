// https://leetcode.com/problems/best-reachable-tower

class Solution {
public:
    vector<int> bestTower(vector<vector<int>>& tw, vector<int>& c, int r) {
        int q=-1,xa=-1,ya=-1;
        sort(tw.begin(),tw.end());
        for(auto &cord:tw)
            {
                int x=cord[0],y=cord[1];
                if(q<cord[2] && abs(c[0]-x)+abs(c[1]-y)<=r)xa=x,ya=y,q=cord[2];
            }
        return {xa,ya};
    }
};