// https://leetcode.com/problems/construct-string-with-repeat-limit

class Solution {
public:
    string repeatLimitedString(string s, int rl) {
        vector<int> f(26,0);
        for(auto i:s)
            f[i-'a']++;
        
        string ans;
        int t=0;
        for(int i=25,j;i>=0;i--)
        {
            
            if(!f[i])continue;
            t=rl;
            while(t--&&f[i])
            {
                ans+=string(1,'a'+i);f[i]--;
            }
            if(f[i])
            {
                j=i-1;
                while(j>=0&&f[j]==0)j--;
                if(j>=0){ans+=string(1,'a'+j);f[j]--;i++;}
                
            }
        }
        
        return ans;
    }
};