// https://leetcode.com/problems/climbing-stairs

class Solution {
public:
    int climbStairs(int n) {
        //Rec
        // if(n<=1) return 1;
        // return climbStairs(n-1)+climbStairs(n-2);
        
        //DP-TD tab

        // vector<int> dp(n+1,0);
        int a=1,b=1;//dp[0]=dp[1]=1;
        for(int i=2;i<=n;i++)
        {
            int t=a+b;
            a=b,b=t;
        }

        return b;

    }
};