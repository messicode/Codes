// https://leetcode.com/problems/climbing-stairs

class Solution {
public:
    
    //memoization helper
    // int hlp(int n,vector<int> &memo)
    // {
    //     if(n==0) return 1;
    //     if(n<0) return 0;
    //     if(memo[n]!=-1)return memo[n];
    //     return memo[n]= climbStairs(n-2) + climbStairs(n-1);
    // }

    int climbStairs(int n) {
        
        int prev1=1,prev2=0,curr=0;
        for(int i=1;i<n+1;i++)
        {
            curr=prev1+prev2;
            prev2=prev1;
            prev1=curr;
        }
        return prev1;
    }

};