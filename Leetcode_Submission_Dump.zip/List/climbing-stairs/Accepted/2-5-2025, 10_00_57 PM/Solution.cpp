// https://leetcode.com/problems/climbing-stairs

class Solution {
public:
    
    //memoization helper
    // int hlp(int n,vector<int> &memo)
    // {
    //     if(n==0) return 1;
    //     if(n<0) return 0;
    //     if(memo[n]!=-1)return memo[n];
    //     return memo[n]= climbStairs(n-2) + climbStairs(n-1);
    // }

    int climbStairs(int n) {
        vector<int> dp(n+1,0);
        dp[0]=1;
        for(int i=1;i<n+1;i++)
        {
            if(i-1>=0)dp[i]+=dp[i-1];
            if(i-2>=0)dp[i]+=dp[i-2];    
        }
        return dp[n];
    }

};