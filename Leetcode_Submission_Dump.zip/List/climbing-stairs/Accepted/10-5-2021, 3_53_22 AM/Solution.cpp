// https://leetcode.com/problems/climbing-stairs

class Solution {
public:
    // unordered_map<int,int> mp;
    int climbStairs(int n) {
        //ITR
        
        
        int a=2,b=3,c=5;
        if(n==1||n==2||n==3)return n;
        
        for(int i=4;i<=n;i++)
        {
            c=a+b;a=b;b=c;
        }
        return c;
        // if(mp.find(n)!=mp.end())return mp[n];
        // if(n==0)return 1;if(n<0)return 0;
        // mp[n]=climbStairs(n-1)+climbStairs(n-2);
        // return mp[n];
    }
};