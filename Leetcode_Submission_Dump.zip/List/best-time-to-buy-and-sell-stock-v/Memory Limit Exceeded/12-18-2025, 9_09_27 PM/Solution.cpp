// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-v

class Solution {
    using ll=long long;
    ll rec(int trx,int i,vector<int>& prc,int k,vector<vector<vector<ll>>> & memo)
    {
        if(i==prc.size() || k==0) return 0;
        if(memo[i][trx+1][k]!=-1) return memo[i][trx+1][k]; 
        ll ans=0;
        if(trx!=-1)//sell or buy now
        {
            ans=0LL+abs(prc[i]-prc[trx])+rec(-1,i+1,prc,k-1,memo);
        }
        else//intiate new from here
        {
            ans=rec(i,i+1,prc,k,memo);
        }
        //hold
        ans=max(ans,rec(trx,i+1,prc,k,memo));
        return memo[i][trx+1][k]=ans;
    }
public:
    long long maximumProfit(vector<int>& prc, int k) {
        vector<vector<vector<ll>>> memo(prc.size()+1,vector<vector<ll>>(prc.size()+2,vector<ll>(k+1,-1)));
        return rec(-1,0,prc,k,memo);
    }
};