// https://leetcode.com/problems/best-time-to-buy-and-sell-stock

class Solution {
public:
    int maxProfit(vector<int>& pr) {
        int h=pr[0],l=pr[0],ans=0;
        for(int i=1;i<pr.size();i++)
        {
            if(l>pr[i])l=pr[i],h=pr[i];
            h=max(pr[i],h);
            ans=max(h-l,ans);
        }
        return ans;
    }
};