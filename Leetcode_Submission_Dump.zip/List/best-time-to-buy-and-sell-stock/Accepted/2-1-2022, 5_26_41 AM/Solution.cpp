// https://leetcode.com/problems/best-time-to-buy-and-sell-stock

class Solution {
public:
    int maxProfit(vector<int>& a) {
        int ans=0,cd=0,mn=a[0];
        for(int i=1;i<a.size();i++)
        {
            if(mn>a[i])mn=a[i];
           // cout<<mn<<" ";
            if(ans<(a[i]-mn))
            ans=a[i]-mn;
        }
        return ans;
    }
};