// https://leetcode.com/problems/best-time-to-buy-and-sell-stock

class Solution {
public:
    int maxProfit(vector<int>& nums) {
        int a=nums[0],mx=0;
        for(int i=1;i<nums.size();i++)
        {
            a=min(a,nums[i]);
            mx=max(mx,nums[i]-a);
        }
        return mx;
    }
};