// https://leetcode.com/problems/best-time-to-buy-and-sell-stock

class Solution {
public:
    int maxProfit(vector<int>& a) {
        int ans=0,prev=a[0];
        for(int i=1;i<a.size();i++)
        {
            if(a[i]>=a[i-1])ans=max(ans,a[i]-prev);
            else prev=min(a[i],prev);
        }
        return ans;
    }
};