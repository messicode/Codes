// https://leetcode.com/problems/best-time-to-buy-and-sell-stock

class Solution {
public:
    int maxProfit(vector<int>& prc) {
        int mn=INT_MAX;
        int ans=0;
        for(int i=0;i<prc.size();i++)
        {
            if(prc[i]<mn)mn=prc[i];
            else ans=max(ans,prc[i]-mn);
            
        }
        return ans;
    }
};