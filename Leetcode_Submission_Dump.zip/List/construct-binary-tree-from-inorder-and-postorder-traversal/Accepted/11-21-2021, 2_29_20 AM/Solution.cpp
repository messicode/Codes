// https://leetcode.com/problems/construct-binary-tree-from-inorder-and-postorder-traversal

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    
    TreeNode* h(vector<int>& io, vector<int>& po,int l,int r,int ro)
    {
        if(l>r)return nullptr;
        // cout<<l<<" "<<r<<"\n";
        int cr,f=-1,f1=-1;
        if(l==r)
        {
            return new TreeNode(io[l]);
                
        }
        for(int i=ro-1;i>=0;i--)
        {if(f!=-1)break;
            for(int j=l;j<=r;j++)
            {
                // cout<<i<<" "<<j<<"|";
                if(po[i]==io[j]){cr=po[i];f=j;f1=i;break;}
            }
        }
        // cout<<cr<<" ";
        TreeNode *t=new TreeNode(cr);
       
        // while(i<io.size())
        // {
        //     if(io[i]==cr)break;i++;
        // }
        
        t->left=h(io,po,l,f-1,f1);
        t->right=h(io,po,f+1,r,f1);
        return t; 
    }
    
    
    TreeNode* buildTree(vector<int>& io, vector<int>& po) {
        
        int cr=po[po.size()-1];
        // cout<<cr<<" ";
        TreeNode *t=new TreeNode(cr);
        int i=0;
        while(i<io.size())
        {
            if(io[i]==cr)break;i++;
        }
        // cout<<i<<"- ";
        t->left=h(io,po,0,i-1,po.size()-1);
        t->right=h(io,po,i+1,io.size()-1,po.size()-1);
        // cout<<cr<<" ";
        return t;
    }
};