// https://leetcode.com/problems/binary-number-with-alternating-bits

class Solution {
public:
    bool hasAlternatingBits(int n) {
        int x=n&1;n>>=1;
        while(n)
        {
            // cout<<x<<"\n";
            if(x==(n&1)) return false;
            x=n&1;
            n>>=1;
        }
        return true;
    }
};