// https://leetcode.com/problems/can-place-flowers

class Solution {
public:
    bool canPlaceFlowers(vector<int>& fb, int n) {
       
        for(int i=0;i<fb.size();i++)
        {
            if(!fb[i])
            {
                if((i==0||fb[i-1]==0)&&(i==fb.size()-1||fb[i+1]==0))n--,i++;
                if(!n)return true;
            }
        }
        return n<=0;
    }
};