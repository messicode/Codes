// https://leetcode.com/problems/can-place-flowers

class Solution {
public:
    bool canPlaceFlowers(vector<int>& fb, int n) {
       
        for(int i=0;i<fb.size();i++)
        {
            if(!fb[i])
            {
                if(i>=1&&fb[i-1]==0&&(i<fb.size()-1)&&fb[i+1]==0)fb[i]=1,i++,n--;
                else if(i==0&&(i<fb.size()-1)&&fb[i+1]==0)fb[i]=1,n--,i++;
                else if(i==fb.size()-1&&i>0&&fb[i-1]==0)fb[i]=1,n--,i++;
                else if(fb.size()==1)fb[i]=1,n--,i++;
            }
        }
        return n<=0;
    }
};