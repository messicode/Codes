// https://leetcode.com/problems/can-place-flowers

class Solution {
public:
    bool canPlaceFlowers(vector<int>& fb, int n) {
        int cn=0,s=fb.size();
        for(int i=0;i<s;i++)
        { 
            if(fb[i])continue;
            if((i==0 || fb[i-1]==0) && (i==s-1 || fb[i+1]==0)){i++;cn++;}
        }
        return cn>=n;
    }
};