// https://leetcode.com/problems/bitwise-and-of-numbers-range

class Solution {
public:
    int rangeBitwiseAnd(int left, int right) {
        
        
        long long int l=left,r=right,l1,r1;
        while(l)
        {
            l1=l;l=l&(l-1);
        }
        while(r)
        {
            r1=r;r=r&(r-1);
        }
        // cout<<left<<" "<<r1<<" "<<right<<"\n";
        if(!(l1&r1))return 0;
        long long ans=left;l=left;
        while(l<=right)
        {
            ans&=l;l++;
        }
        return ans;
    }
};