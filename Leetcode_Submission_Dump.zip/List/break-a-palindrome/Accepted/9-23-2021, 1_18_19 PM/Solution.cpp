// https://leetcode.com/problems/break-a-palindrome

class Solution {
public:
    string breakPalindrome(string p) {
        int n=p.size();
        if(n==1)return "";
        int pos=-1;
        for(int i=0;i<(n/2);i++)
        {
            if(p[i]!='a'){pos=i;break;}
        }
        cout<<pos<<" "<<p;
        if(pos==-1)p[n-1]='b';
        else p[pos]='a';
        return p;
    }
};