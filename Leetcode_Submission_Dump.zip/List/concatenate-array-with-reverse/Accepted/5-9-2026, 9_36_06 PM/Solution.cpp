// https://leetcode.com/problems/concatenate-array-with-reverse

class Solution {
public:
    vector<int> concatWithReverse(vector<int>& nums) {
        int n=nums.size();
        vector<int> ans(n*2);
        for(int i=0;i<n;i++) ans[i]=nums[i];
        for(int i=0;i<n;i++) ans[i+n]=nums[n-1-i];
        return ans;
    }
};