// https://leetcode.com/problems/binary-tree-tilt

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    int ans;
    int h(TreeNode* root)
    {
        if(root==nullptr)return 0;
        int l=h(root->left),r=h(root->right);
        ans+=abs(l-r);
        return root->val+l+r;
    }
    
    int findTilt(TreeNode* root) {
        ans=0;
        h(root);
        return ans;
    }
};