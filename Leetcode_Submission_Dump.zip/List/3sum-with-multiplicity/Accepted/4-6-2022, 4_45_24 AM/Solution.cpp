// https://leetcode.com/problems/3sum-with-multiplicity


const long long MOD=1000000007;

long long int weiwei(long long int n,long long int r)
{
    long long int d=min(r,n-r),a=n,z=1LL;r=max(r,n-r);
    
    for(long long int i=n;i>r;i--)
    {
        z=(z*i);
        // cout<<z<<"\n";
    }
    // cout<<"-------------\n";
    for(long long int i=d;i>0LL;i--)
    {
        z=(z/i)%MOD;
        // cout<<z<<"\n";
    }
    return z;
}


class Solution {
public:
    int threeSumMulti(vector<int>& arr, int t) {
        vector<int> v(101,0);
        for(auto i:arr)v[i]++;
        long long ans=0;
        for(int i=0;i<=100;i++)
        {
            if(!v[i])continue;
            
            int j=i,k=100;
            while(j<=k)
            {
                
                while(j<k&&!v[j])j++;
                while(j<k&&!v[k])k--;
                if(j>k)break;
                if((i+j+k)==t)
                {
                    // cout<<i<<" "<<j<<" "<<k<<"\n";
                    long long c1=v[i],c2=v[j],c3=v[k],a=1;
                    if(i==j&&j==k)
                    {
                        if(c1>2)
                        {ans=(ans+(weiwei(c1,3))%MOD)%MOD;}
                    }
                    else if(i==j)
                    {
                        if(c1>1)
                        {ans=(ans+(weiwei(c1,2)*c3)%MOD)%MOD;}
                    }
                    else if(k==j)
                    {
                        if(c3>1)
                        {ans=(ans+(weiwei(c3,2)*c1)%MOD)%MOD;}
                    }
                    else {ans=(ans+((c2*c1)%MOD)*c3)%MOD;}    
                    
                    // cout<<ans<<"\n";
                    j++,k--;
                }
                else if((i+j+k)>t)k--;
                else j++; 
                }
            }
            return ans;
        }
};