// https://leetcode.com/problems/3sum-with-multiplicity


const long long MOD=1000000007;

// long long int weiwei(long long int n,long long int r)
// {
//     long long int d=min(r,n-r),a=n,z=1LL;r=max(r,n-r);
    
//     return z;
// }


class Solution {
public:
    int threeSumMulti(vector<int>& arr, int t) {
        vector<int> v(101,0);
        for(auto i:arr)v[i]++;
        long long ans=0;
        for(int i=0;i<=100;i++)
        {
            if(!v[i])continue;
            
            int j=i,k=100;
            while(j<=k)
            {
                
                while(j<k&&!v[j])j++;
                while(j<k&&!v[k])k--;
                if(j>k)break;
                if((i+j+k)==t)
                {
                    // cout<<i<<" "<<j<<" "<<k<<"\n";
                    long long c1=v[i],c2=v[j],c3=v[k],a=1;
                    if(i==j&&j==k)
                    {
                        if(c1>2)
                        {ans=(ans+(((c1*(c1-1LL)*(c1-2LL))/6))%MOD)%MOD;}
                    }
                    else if(i==j)
                    {
                        if(c1>1)
                        {ans=(ans+((c1*(c1-1LL)*c3)/2)%MOD)%MOD;}
                    }
                    else if(k==j)
                    {
                        if(c3>1)
                        {ans=(ans+((c3*(c3-1LL)*c1)/2)%MOD)%MOD;}
                    }
                    else {ans=(ans+((c2*c1)%MOD)*c3)%MOD;}    
                    
                    // cout<<ans<<"\n";
                    j++,k--;
                }
                else if((i+j+k)>t)k--;
                else j++; 
                }
            }
            return ans;
        }
};