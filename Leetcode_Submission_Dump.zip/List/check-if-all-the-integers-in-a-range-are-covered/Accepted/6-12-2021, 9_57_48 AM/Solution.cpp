// https://leetcode.com/problems/check-if-all-the-integers-in-a-range-are-covered

class Solution {
public:
    bool isCovered(vector<vector<int>>& r, int l, int ri) {
        
        vector<int> v(52,0);int n=r.size();
        for(int i=0;i<n;i++)
        {
            v[r[i][0]]+=1;
            v[r[i][1]+1]+=-1;
        }
        for(int i=1;i<52;i++) {v[i]+=v[i-1];}
       // for(int i=0;i<52;i++) cout<<v[i]<<" ";
        for(int i=l;i<=ri;i++)
        {
            if(v[i]==0) return false;
        }
            
        return true;
        
    }
};