// https://leetcode.com/problems/all-elements-in-two-binary-search-trees

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:

    void h(TreeNode *t,vector<int> &a)
    {
        if(t==nullptr)return;
        h(t->left,a);
        a.push_back(t->val);
        h(t->right,a);
    }
    vector<int> getAllElements(TreeNode* r1, TreeNode* r2) {
            
        vector<int> ans,l1,l2;
        h(r1,l1);
        h(r2,l2);
        int i=0,j=0;
        while(i<l1.size()&&j<l2.size())
        {
            if(l1[i]<l2[j])
                ans.push_back(l1[i++]);
            else ans.push_back(l2[j++]);
        }
        while(i<l1.size())ans.push_back(l1[i++]);
        while(j<l2.size())ans.push_back(l2[j++]);
        
        return ans;
    }
};