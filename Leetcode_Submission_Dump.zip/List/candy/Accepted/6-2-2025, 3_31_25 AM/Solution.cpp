// https://leetcode.com/problems/candy

class Solution {
public:
    int candy(vector<int>& rt) {
        if(rt.size()==1) return 1;
        int n=rt.size(), ans=0;
        vector<int> cnd(n,1);

        for(int i=1;i<n;i++)
            if(rt[i]>rt[i-1]) cnd[i]=cnd[i-1]+1;
        for(int i=n-1;i>0;i--)
            if(rt[i-1]>rt[i]) cnd[i-1]=max(cnd[i-1], cnd[i]+1);
        for(int i=0;i<n;i++)ans+=cnd[i];
        return ans;
       
    }
};