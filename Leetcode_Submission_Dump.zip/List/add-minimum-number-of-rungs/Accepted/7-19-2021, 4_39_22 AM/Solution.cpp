// https://leetcode.com/problems/add-minimum-number-of-rungs

class Solution {
public:
    int addRungs(vector<int>& r, int d) {
        int p=0,c=0;
        for(int i=0;i<r.size();i++)
        {int x=r[i]-p;
            if(x>d)
            {
                c+=(x-1)/d;
            }
         p=r[i];
        }
        return c;
        
    }
};