// https://leetcode.com/problems/construct-binary-search-tree-from-preorder-traversal

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    TreeNode* bstFromPreorder(vector<int>& pr,int l=0,int r=-1) {
        
        if(r==-1) r=pr.size()-1;
        if(l>r)return NULL;
        TreeNode *t=new TreeNode(pr[l]);
        // cout<<t->val<<" "<<pr[l]<<" "<<l<<" "<<r;
        if(r==l)return t;
        int i=l,x=pr[l];
        for(i=l+1;i<=r;i++)
        {
            if(pr[i]>x)break;
        }
        t->left=bstFromPreorder(pr,l+1,i-1);
        t->right=bstFromPreorder(pr,i,r);
        return t;
    }
};