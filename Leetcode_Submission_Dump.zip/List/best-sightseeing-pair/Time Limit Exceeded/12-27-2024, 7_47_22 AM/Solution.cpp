// https://leetcode.com/problems/best-sightseeing-pair

class Solution {
public:
    int maxScoreSightseeingPair(vector<int>& vals) {
        int ans=0;
        for(int i=0;i<vals.size();i++)
        {
            for(int j=i+1;j<vals.size();j++)
            {
                ans=max(ans, vals[i]+vals[j]-(j-i));
            }
        }
        return ans;
    }
};