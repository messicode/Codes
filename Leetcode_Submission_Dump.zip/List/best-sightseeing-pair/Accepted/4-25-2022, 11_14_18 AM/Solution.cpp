// https://leetcode.com/problems/best-sightseeing-pair

class Solution {
public:
    int maxScoreSightseeingPair(vector<int>& v) {
        int ans=0;
        int mx=v[0];
        for(int i=1;i<v.size();i++)
        {
            mx--;
            ans=max(ans,mx+v[i]);
            mx=max(v[i],mx);
        }
     
        return ans;   
    }
};