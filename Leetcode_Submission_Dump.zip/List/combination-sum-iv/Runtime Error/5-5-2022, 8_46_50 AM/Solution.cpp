// https://leetcode.com/problems/combination-sum-iv

class Solution {
public:
    int combinationSum4(vector<int>& a, int t) {
        int dp[t+1];
        for(int i=0;i<=t;i++)dp[i]=0;
        dp[0]=1;
        for(int i=0;i<t;i++)
        {
            if(dp[i]==0)continue;
            for(int j=0;j<a.size();j++)
            {
                if(i+a[j]<=t)dp[i+a[j]]+=dp[i];
            }
        }
        return dp[t];
    }
};