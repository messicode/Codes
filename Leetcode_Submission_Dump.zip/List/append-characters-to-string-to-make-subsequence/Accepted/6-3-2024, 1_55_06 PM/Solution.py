// https://leetcode.com/problems/append-characters-to-string-to-make-subsequence

class Solution:
    def appendCharacters(self, s: str, t: str) -> int:
        i=0
        j=0
        while j<len(t):
            while i<len(s) and s[i]!=t[j]:
                i+=1
            if i>=len(s): break
            i+=1
            j+=1
        return len(t)-j