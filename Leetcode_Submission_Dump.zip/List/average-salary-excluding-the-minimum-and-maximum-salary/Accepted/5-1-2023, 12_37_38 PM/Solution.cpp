// https://leetcode.com/problems/average-salary-excluding-the-minimum-and-maximum-salary

class Solution {
public:
    double average(vector<int>& sal) {
        int s=0,mn=sal[0],mx=sal[0];
        for(auto i:sal)
        {
            s+=i;mn=min(mn,i);mx=max(mx,i);
        }
        return (1.0*s-mn-mx)/(sal.size()-2);
    }
};