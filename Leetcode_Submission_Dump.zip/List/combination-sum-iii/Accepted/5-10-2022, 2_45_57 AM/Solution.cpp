// https://leetcode.com/problems/combination-sum-iii

class Solution {
public:
    
    void rec(int i,int k,int n,vector<int> &c,vector<vector<int>> &ans)
    {
        
        if(i>10||n<0||c.size()>k)return;
        if(n==0)
        {
            if(c.size()==k)
                ans.push_back(c);
            return;
        }
        
        rec(i+1,k,n,c,ans);
        c.push_back(i);
        rec(i+1,k,n-i,c,ans);
        c.pop_back();
        
    }
    
    vector<vector<int>> combinationSum3(int k, int n) {
        vector<vector<int>> ans;
        vector<int> c;
        rec(1,k,n,c,ans);
        return ans;
    }
};