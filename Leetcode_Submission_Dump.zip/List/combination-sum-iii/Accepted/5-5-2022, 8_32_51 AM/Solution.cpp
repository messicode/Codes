// https://leetcode.com/problems/combination-sum-iii

void candy(int n,int t,int k,vector<vector<int>> &ans,vector<int> cur)
{
    if(n<0||cur.size()>k||t<0)return;
    if(t==0)
    { 
        if(cur.size()==k)ans.push_back(cur);return;
    }
    
    candy(n-1,t,k,ans,cur);
    cur.push_back(n);
    candy(n-1,t-n,k,ans,cur);
    
}


class Solution {
public:
    vector<vector<int>> combinationSum3(int k, int t) {
        vector<vector<int>> ans;
        vector<int> cur;
        candy(9,t,k,ans,cur);
        return ans;
    }
};