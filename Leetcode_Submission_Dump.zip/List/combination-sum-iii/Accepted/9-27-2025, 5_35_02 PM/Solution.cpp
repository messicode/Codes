// https://leetcode.com/problems/combination-sum-iii

class Solution {

    vector<vector<int>> rec(int n, int k, vector<bool> &used,vector<vector<int>> &ans,int prev)
    {   if(n<0 || k<0) return ans;
        if(n==0 &&k==0)
        {
            vector<int> a;
            for(int i=1;i<10;i++)
            {
                if(used[i])a.push_back(i);
            }
            if(!a.empty())ans.push_back(a);
            return ans;
        }
        for(int i=prev;i<10;i++)
        {
            if(i>n)break;
            if(used[i])continue;
            used[i]=true;
            rec(n-i,k-1,used,ans,i+1);
            used[i]=false;
        }
        return ans;
    }
public:
    vector<vector<int>> combinationSum3(int k, int n) {
        vector<vector<int>> ans;
        vector<bool> used(10,false);
        return rec(n,k,used,ans,1);
    }
};