// https://leetcode.com/problems/add-binary

class Solution {
public:
    string addBinary(string a, string b) {
        
        int c=0,i=0,mx=max(a.size(),b.size());
        string ans="";
        while(i<mx)
        {
            if(i<b.size() )c+=b[b.size()-i-1]-'0';
            if(i<a.size())c+=a[a.size()-1-i]-'0';
            ans+='0'+(c%2);
            c=c/2;
            i++;
        }
        if(c==1)ans.push_back('1');
        reverse(ans.begin(),ans.end());
        return ans;
    }
};