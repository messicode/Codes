// https://leetcode.com/problems/add-binary

class Solution {
public:
    string addBinary(string a, string b) {
        string s="",x="";
        int i=a.size()-1,sm,j=b.size()-1,c=0;
        while(i>=0&&j>=0)
        {
            sm=(a[i]-'0')+(b[j]-'0')+c;
            x='0'+(sm%2);
            s.insert(0,x);
            c=(sm>1)?1:0;
            i--,j--;
        }
        while(i>=0)
        {
            sm=(a[i]-'0')+c;
            x='0'+(sm%2);
            s.insert(0,x);
            c=(sm>1)?1:0;
            i--;
        }
        while(j>=0)
        {
            sm=(b[j]-'0')+c;
            x='0'+(sm%2);
            s.insert(0,x);
            c=(sm>1)?1:0;
            j--;
        }
        if(c)s.insert(0,"1");
            
        return s;
    }
};