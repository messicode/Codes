// https://leetcode.com/problems/array-nesting

class Solution {
public:
    int arrayNesting(vector<int>& nums) {
        
        int n=nums.size(),mx=0;
        vector<int> st(n,0);
        for(int i=0;i<n;i++)
        {
            int j=i,c=0;
            while(st[j]!=1)
            {
                // cout<<nums[i]<<" ";
                st[j]=1;
                j=nums[j];
                c++;
            }
            //cout<<"-";
            mx=max(c,mx);
        }
        return mx;
    }
};