// https://leetcode.com/problems/arranging-coins

class Solution {
public:
    int arrangeCoins(int n) {
        int x=(sqrt((n*8.0)+1.0)-1.0)/2;
        return x;
    }
};