// https://leetcode.com/problems/add-two-numbers

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
        
        ListNode *h=NULL,*l=NULL;
        int x=0,c=0;
        while(l1!=NULL&&l2!=NULL)
        {
            x=l1->val+l2->val+c;
            c=(x>9)?1:0;
            x%=10;
            if(h==NULL)l=new ListNode(x),h=l;
            else l->next=new ListNode(x),l=l->next;
            l1=l1->next;l2=l2->next;
        }
        while(l1!=NULL)
        {
            x=l1->val+c;
            c=(x>9)?1:0;
            x%=10;
            l->next=new ListNode(x),l=l->next;l1=l1->next;
        }
    
        while(l2!=NULL)
        {
            x=l2->val+c;
            c=(x>9)?1:0;
            x%=10;
            l->next=new ListNode(x),l=l->next;l2=l2->next;
        }
        if(c!=0)
            l->next=new ListNode(c),l=l->next;
        return h;
    }
};