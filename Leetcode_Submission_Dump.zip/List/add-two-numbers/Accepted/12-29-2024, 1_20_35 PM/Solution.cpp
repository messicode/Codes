// https://leetcode.com/problems/add-two-numbers

/**
 * Definition for singly-linked list.
 * struct ListNode {
 *     int val;
 *     ListNode *next;
 *     ListNode() : val(0), next(nullptr) {}
 *     ListNode(int x) : val(x), next(nullptr) {}
 *     ListNode(int x, ListNode *next) : val(x), next(next) {}
 * };
 */
class Solution {
public:
    ListNode* addTwoNumbers(ListNode* l1, ListNode* l2) {
      if(l1==nullptr && l2==nullptr) return nullptr;
      else if(l1==nullptr) return l2;
      else if(l2==nullptr) return l1;
      int x=l1->val+l2->val;
      ListNode *tmp=new ListNode(x%10);
      tmp->next=addTwoNumbers(l1->next,l2->next);
      if(x>=10) tmp->next=addTwoNumbers(tmp->next,new ListNode(1));
      return tmp;
    }
};