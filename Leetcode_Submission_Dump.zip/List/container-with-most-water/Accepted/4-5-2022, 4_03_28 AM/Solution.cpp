// https://leetcode.com/problems/container-with-most-water

class Solution {
public:
    int maxArea(vector<int>& h) {
        
        int l=0,r=h.size()-1,ans=0;
        while(l<r)
        {
            // cout<<l<<" "<<r<<"\n";
            ans=max(ans,(min(h[l],h[r])*(r-l)));
            
            if(h[l]<h[r])l++;
            else if(h[l]>h[r])r--;
            else l++,r--;
        }
        return ans;
    }
};