// https://leetcode.com/problems/container-with-most-water

class Solution {
public:
    int maxArea(vector<int>& ht) {
        
        //This is optimal since 
        // 2 ways to see
        //proof by contr-> if i dont pass the optimal then these must not be the optimal solution as i would've found something bigger than the opposite pointers value at a farther distance and then that would be the optimal
        //prrof by matrix-> When i move the smaller one I eliminate all the cases that this small value can form with all other elements and simply take the farthest one, this ensures im picking the max solution I can have with each small element  
        int l=0,r=ht.size()-1,ans=0;
        while(l<r)
        {
            ans=max(ans,(r-l)*min(ht[l],ht[r]) );
            int f=0;
            if(ht[l]<=ht[r]) f++;
            if(ht[r]<=ht[l]) r--;
            l+=f;
        }
        return ans;
    }
};