// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-with-transaction-fee

class Solution {
public:
    int maxProfit(vector<int>& prc, int fee) {
        int n=prc.size(),free=0,hold=-prc[0];

        for(int i=0;i<n;i++)
        {
            //prev free or prev held sold
            int new_free=max(hold+prc[i]-fee,free);
            //continue holding stock or buy from free state
            int new_hold=max(hold,free-prc[i]);
            hold=new_hold,free=new_free;
        }
        return free;
    }
};