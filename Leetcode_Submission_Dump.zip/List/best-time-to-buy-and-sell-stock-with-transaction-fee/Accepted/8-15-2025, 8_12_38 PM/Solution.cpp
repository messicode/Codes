// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-with-transaction-fee

class Solution {
public:
    int maxProfit(vector<int>& prc, int fee) {
        vector<int> hold(prc.size(),0), free(prc.size(),0);
        //these arrays are for the 2 states that you can have on a given day
        hold[0]=-prc[0];//Only when stock held
        free[0]=0;

        for(int i=1;i<prc.size();i++)
        {
            //selling and no action: either sell the held stock or continue with none
            free[i]=max(free[i-1],hold[i-1]+prc[i]-fee);
            //buy some stock after free state or keep holding previously held stock
            hold[i]=max(hold[i-1],free[i-1]-prc[i]); 
        }
        //no point in ending on a held stock and return the optimal of selling on the last day or continue being free  
        return free[prc.size()-1];
    }
};