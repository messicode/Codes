// https://leetcode.com/problems/ambiguous-coordinates

class Solution {
public:
    
    bool isv(string s,int p)
    {
        int i=0;
        if(s[1]=='0'&&!(s[2]=='.'||s[2]==','))return false;
        int pos=s.find('.'); 
        if(s[p-1]=='0'&&(pos!=-1&&pos<p))return false;
        cout<<s<<" "<<pos<<"\n";
        if(s[p+2]=='0'&&!(s[p+3]=='.'||s[p+3]==')'))return false;
        pos=s.find('.',p+1);
        
        if(s[s.size()-2]=='0'&&(pos!=-1&&pos>p))return false;
       
        return true;
    }
    
    vector<string> ambiguousCoordinates(string s) {
        vector<string> ans;
        for(int i=2;i<s.size()-1;i++)//comma
        {
            for(int j=2;j<=i;j++)//1st dec
            {
                for(int k=i+1;k<s.size();k++) //2nd dec
                {string a="";
                    for(int z=0;z<s.size();z++)
                    {
                        if(z==i)a+=", ";
                        if(z==j&&z!=i) a+=".";
                        if(z==k&&z!=s.size()-1) a+=".";
                        a+=s[z];
                    }
                 if(isv(a,i+(j!=i)))
                 ans.push_back(a);
                }
            }
            
        }
        return ans;
    }
};