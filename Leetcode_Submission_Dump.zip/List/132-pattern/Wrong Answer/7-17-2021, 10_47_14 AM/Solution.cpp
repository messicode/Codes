// https://leetcode.com/problems/132-pattern

class Solution {
public:
    bool find132pattern(vector<int>& a) {
        
        for(int i=1;i<a.size()-1;i++)
        {
            if(a[i]>a[i+1]&&a[i-1]<a[i+1]&&a[i]>a[i-1]&&a[i+1]!=a[i-1]) return true;
        }
        return false;
    }
};