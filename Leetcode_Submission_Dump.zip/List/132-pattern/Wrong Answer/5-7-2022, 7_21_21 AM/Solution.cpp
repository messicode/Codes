// https://leetcode.com/problems/132-pattern

class Solution {
public:
    bool find132pattern(vector<int>& a) {
         
        stack<int> st;int mn=a[0];
        vector<int> m(a.size());m[0]=INT_MAX;
        for(int i=1;i<a.size();i++){mn=min(mn,a[i]);m[i]=(mn==a[i])?INT_MAX:mn;}
        
        for(int i=a.size()-1;i>=0;i--)
        {
            if(m[i]==INT_MAX)continue;
            if(!st.empty()&&st.top()>m[i]&&st.top()<a[i])return true;
            if(st.empty()||a[i]>st.top())st.push(a[i]);
        }
        return false;
    }
};