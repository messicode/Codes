// https://leetcode.com/problems/backspace-string-compare

class Solution {
public:
    bool backspaceCompare(string s, string t) {
        int i=s.size(),j=t.size();
       int c=0;
        while(i>=0&&j>=0)
        {
            i--,j--;
            while(i>=0&&s[i]=='#'){c=0;while(i>=0&&s[i]=='#')i--,c++;i-=c;}
            while(j>=0&&t[j]=='#'){c=0;while(j>=0&&t[j]=='#')j--,c++;j-=c;}
            if(i>=0&&j>=0&&s[i]!=t[j])return false;
            
        }
        if(i>=0||j>=0)return false;        
        return true;
        
    }
};