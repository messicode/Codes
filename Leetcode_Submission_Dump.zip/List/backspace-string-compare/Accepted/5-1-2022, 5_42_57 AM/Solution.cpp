// https://leetcode.com/problems/backspace-string-compare


int h(int i,string &s)
{
    // cout<<s<<" "<<i<<"\n"; 
    int c=1;i--;
    while(i>=0&&(c||s[i]=='#'))
    {
        if(s[i]=='#')c++;
        else c--;
        i--;
    }
    return i;
}

class Solution {
public:
    bool backspaceCompare(string s, string t) {
        int i=s.size(),j=t.size();
       int c=0;
        while(i>=0&&j>=0)
        {
            i--,j--;
            if(i>=0&&s[i]=='#')i=h(i,s);
            if(j>=0&&t[j]=='#')j=h(j,t);
            if(i>=0&&j>=0&&s[i]!=t[j])return false;
            
        }
        if(i>=0||j>=0)return false;        
        return true;
        
    }
};