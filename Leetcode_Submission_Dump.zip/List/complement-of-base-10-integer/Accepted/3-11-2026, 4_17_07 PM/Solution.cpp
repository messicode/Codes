// https://leetcode.com/problems/complement-of-base-10-integer

class Solution {
public:
    int bitwiseComplement(int n) {
        if(!n)return 1;
        int sz=log2(n)+1,mask=0;
        while(sz--)mask=((mask<<1)|1);
        return n^mask;
    }
};