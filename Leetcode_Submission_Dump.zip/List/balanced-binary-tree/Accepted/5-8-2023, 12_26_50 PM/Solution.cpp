// https://leetcode.com/problems/balanced-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    bool v=true;
    int hi(TreeNode* rt)
    {
        if(rt==nullptr) return 0;
        int h1=hi(rt->left);
        int h2=hi(rt->right);
        if(abs(h1-h2)>1)v=false;
        return 1+max(h1,h2);
    }

    bool isBalanced(TreeNode* root) {
        hi(root);
        return v;
    }
};