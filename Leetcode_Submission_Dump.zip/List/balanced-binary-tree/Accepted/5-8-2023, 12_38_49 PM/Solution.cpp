// https://leetcode.com/problems/balanced-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
public:
    int hi(TreeNode* rt,bool &v)
    {
        if(rt==nullptr) return 0;
        int h1=hi(rt->left,v);if(h1==-1) return -1;
        int h2=hi(rt->right,v);if(h2==-1) return -1;
        if(abs(h1-h2)>1){v=false;return -1;}
        return 1+max(h1,h2);
    }

    bool isBalanced(TreeNode* root) {
        bool v=true;
        hi(root,v);
        return v;
    }
};