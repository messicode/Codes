// https://leetcode.com/problems/balanced-binary-tree

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class Solution {
//Better code: dont use -1 and let calls update values
    bool dfs(TreeNode* root, int &h)
    {
        if(root==nullptr){h=-1; return true;}
        int l,r;
        
        if(dfs(root->left,l) && dfs(root->right,r) && abs(l-r)<2)
        {h=1+max(l,r);return true;}
        return false;
    }
public:
    bool isBalanced(TreeNode* root) {
        int h;
        return dfs(root,h);
    }
};