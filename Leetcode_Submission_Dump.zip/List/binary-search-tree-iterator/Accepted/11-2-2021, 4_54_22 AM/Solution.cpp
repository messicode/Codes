// https://leetcode.com/problems/binary-search-tree-iterator

/**
 * Definition for a binary tree node.
 * struct TreeNode {
 *     int val;
 *     TreeNode *left;
 *     TreeNode *right;
 *     TreeNode() : val(0), left(nullptr), right(nullptr) {}
 *     TreeNode(int x) : val(x), left(nullptr), right(nullptr) {}
 *     TreeNode(int x, TreeNode *left, TreeNode *right) : val(x), left(left), right(right) {}
 * };
 */
class BSTIterator {
public:
    
    vector<int> v;int sz=0,pos=0;
    
    void pp(vector<int> &v,TreeNode *root)
    {
        if(root==nullptr)return;
        pp(v,root->left);
        v.push_back(root->val);
        pp(v,root->right);
        
    }
    
    BSTIterator(TreeNode* root) {
        pp(v,root);   
        sz=v.size();
        // for(auto i:v)cout<<i<<" ";
    }
    
    int next() {
        return v[pos++];
    }
    
    bool hasNext() {
        if(sz==0||(pos>=sz))return false;
        return true;
    }
};

/**
 * Your BSTIterator object will be instantiated and called as such:
 * BSTIterator* obj = new BSTIterator(root);
 * int param_1 = obj->next();
 * bool param_2 = obj->hasNext();
 */