// https://leetcode.com/problems/combination-sum-ii


void candy(vector<int> cur,vector<vector<int>> &ans,vector<int> mp,int n,int t)
{
    if(n<=0||t<0)return;
    if(t==0)
    {
        ans.push_back(cur);return;
    }
    int nc=n-1;
    while(nc>=0&&mp[nc]==0)nc--;
    // cout<<n<<"\n";
    candy(cur,ans,mp,nc,t);//dont pick
    mp[n]--;cur.push_back(n);
    if(mp[n]>=0)candy(cur,ans,mp,n,t-n);
    
}

class Solution {
public:
    vector<vector<int>> combinationSum2(vector<int>& c, int t) {
        vector<vector<int>> ans;
        vector<int> cur,mp(51,0);
        for(auto i:c)mp[i]++;
        int nc=50;
        while(nc>=0&&mp[nc]==0)nc--;
    
        
        candy(cur,ans,mp,nc,t);
        return ans;
    }
};