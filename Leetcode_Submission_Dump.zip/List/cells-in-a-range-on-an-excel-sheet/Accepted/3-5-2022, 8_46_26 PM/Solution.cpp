// https://leetcode.com/problems/cells-in-a-range-on-an-excel-sheet

class Solution {
public:
    vector<string> cellsInRange(string s) {
        vector<string> ans;
        int c=s[3]-'A',r=s[4]-'0';
        for(int i=s[0]-'A';i<=c;i++)
        {
            for(int j=s[1]-'0';j<=r;j++)
            {
                string a;a=('A'+i);a+=('0'+j);
                ans.push_back(a);
            }
        }
        return ans;
    }
};