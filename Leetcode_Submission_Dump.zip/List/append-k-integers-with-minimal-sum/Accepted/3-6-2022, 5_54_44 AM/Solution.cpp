// https://leetcode.com/problems/append-k-integers-with-minimal-sum

class Solution {
public:
    long long minimalKSum(vector<int>& nums, int k) {
     long long i=1,ans=0;
        
        set<int> s;
        for(auto z:nums)s.insert(z);
        auto p=s.begin(),c=p;c++;
        if(*p!=1)
        {
            int x=*p-i;
            x=min(k,x);k-=x;
            ans+=(((x+0LL)*1LL*(x+1LL))/2LL);
            
        }
        for(;k>0&&c!=s.end();c++,p++)
        {
            i=(*p)+1;
            int cr=*c;
            if(i>=cr)continue;
            ans-=((i*(i-1))/2LL);
            int x=cr-i;
            x=min(k,x);k-=x;
            ans+=(((i+x+0LL)*1LL*(i+x-1LL))/2LL);
            // cout<<i<<" "<<k<<" "<<*p<<" "<<cr<<" | ";
        }
        // cout<<ans<<" ";
        if(k>0)
        {
            i=*(s.rbegin())+1;
            // cout<<i<<endl;
            ans-=((i*(i-1))/2LL);
            ans+=(((i+k+0LL)*1LL*(i+k-1LL))/2LL);
        }
        // cout<<endl;
        return ans;
    }
};