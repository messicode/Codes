// https://leetcode.com/problems/append-k-integers-with-minimal-sum

class Solution {
public:
    long long minimalKSum(vector<int>& nums, int k) {
     long long i=1,ar=0,ans=0;
        sort(nums.begin(),nums.end());
        while(ar<nums.size()&&k>0)
        {
            if(ar<nums.size()&&i<nums[ar])
            {
                ans+=i;k--;
            }
            else if(ar<nums.size()&&nums[ar]==i)
            {while(ar<nums.size()&&nums[ar]==i)ar++;
            }
            i++;
        }
        while(ar>=nums.size()&&k>0){ans+=i;i++;k--;}
        return ans;
    }
};