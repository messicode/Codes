// https://leetcode.com/problems/champagne-tower

class Solution {
public:
    //REC
    double porit(double por,int l,int g,int lvl)
    {
        if(l==1&&g==1) return (por-1.0)/2.0;
        if(g<1||l<1||por<=1)return 0;
        
        double ans=porit(por,l-1,g,lvl)+0.0+porit(por,l-1,g-1,lvl);
        if(lvl==l)return ans;
        else if(ans>1) return (ans-1.0)/2.0;
        else return 0;
    }
    
    double champagneTower(int por, int l, int g) {
        
        if(por==0)return 0;
        if(l==0&&g==0)return 1;
        l++;g++;
        return porit(por*1.0,l,g,l);
    }
};