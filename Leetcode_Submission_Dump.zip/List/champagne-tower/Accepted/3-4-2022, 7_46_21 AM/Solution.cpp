// https://leetcode.com/problems/champagne-tower

class Solution {
public:
    double champagneTower(int p, int l, int g) {
        // if(p>5050)return 1;
        vector<double> ans(6100,0);
        ans[0]=p;
        int gid=((l*(l+1))/2)+g;
        int cl=0,cg=0;
        for(int i=0;i<gid-g;i++)
        {
            int c=(((cl+2)*(cl+1))/2)+cg;
            // cout<<i<<" "<<c<<"\n";
            if(ans[i]>1&&c<ans.size())
            {
                
                ans[c]+=(ans[i]-1.0)/2.0;
                c++;
                if(c<ans.size())ans[c]+=(ans[i]-1.0)/2.0;
            }
                
            if(cg==cl)cl++,cg=0;
            else cg++;
        }
        return (ans[gid]>1)?1:ans[gid];
    }
};