// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-with-cooldown

class Solution {
public:
    int maxProfit(vector<int>& p) {
     
        vector<int> v(p.size(),0);
        int a=p[0],pos=-1,gmn=p[0];v[0]=0;
        
        for(int i=1;i<p.size();i++)
        {
            if(p[i]<p[i-1])
            {
                v[i]=v[i-1];a=p[i];pos=i;
            }
            else 
            {
                if(a>=p[i]){a=p[i];pos=i;}
                int a3=0,a2=0;
                if(i>=3)a3=p[i]-p[i-1]+v[i-3];
                if(pos>=2)a2=p[i]-a+v[pos-2];
                v[i]=max({v[i-1],a3,p[i]-a,a2,p[i]-gmn,0});
            }
            gmn=min(gmn,p[i]);
        }
        
        return v[v.size()-1];
    }
};