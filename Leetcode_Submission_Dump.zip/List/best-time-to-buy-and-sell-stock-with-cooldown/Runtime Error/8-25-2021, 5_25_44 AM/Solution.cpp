// https://leetcode.com/problems/best-time-to-buy-and-sell-stock-with-cooldown

class Solution {
public:
    int maxProfit(vector<int>& p,int i=0) {
        if(i==p.size())return 0;
        
        int mx=p[i],mn=p[i],val=0;
        for(;i<p.size();i++)
        {
           if(p[i]>mx)
           {
               mx=p[i];
               val=max(val,(mx-mn+maxProfit(p,i+2)));
           }
           else
           {
               mn=mx=p[i];
           }
            
        }
        return val;
    }
};