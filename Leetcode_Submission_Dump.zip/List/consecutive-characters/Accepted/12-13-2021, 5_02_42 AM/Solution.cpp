// https://leetcode.com/problems/consecutive-characters

class Solution {
public:
    int maxPower(string s) {
        int a=1,w=1;
        for(int i=1;i<s.size();i++)
        {
            if(s[i]==s[i-1])a++;
            else a=1;
            w=max(a,w);
        }
        return w;
    }
};