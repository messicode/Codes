// https://leetcode.com/problems/all-paths-from-source-to-target


void dfs(vector<int> cl,vector<vector<int>>& gr,vector<vector<int>>& list,int n,int cn)
{
    
    if(cn==n-1)
    {
        cl.push_back(cn);
        list.push_back(cl);return;
    }
    cl.push_back(cn);
    for(int i=0;i<gr[cn].size();i++)
    {
        dfs(cl,gr,list,n,gr[cn][i]);
    }
    cl.pop_back();
}

class Solution {
public:
    vector<vector<int>> allPathsSourceTarget(vector<vector<int>>& gr) {
        
        int n=gr.size();
        vector<vector<int>> list;
        vector<int> cl;
        dfs(cl,gr,list,n,0);
        return list;
        
    }
};