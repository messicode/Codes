// https://leetcode.com/problems/check-if-all-characters-have-equal-number-of-occurrences

class Solution {
public:
    bool areOccurrencesEqual(string s) {
        //if(s.size()==1)return false;
        vector<int> c(26,0);
        for(int i=0;i<s.size();i++)
            c[s[i]-'a']++;
        int p,i;
        for(i=0;i<26;i++)
            if(c[i]){p=c[i];break;}
        i++;
        for(;i<26;i++)
            if(c[i]!=0&&c[i]!=p)return false;
      return true;
    }
};